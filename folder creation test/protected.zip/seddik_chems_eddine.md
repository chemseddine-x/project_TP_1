 # SEDDIK CHEMS EDDINE
 
 bonjour ,
 C'est seddik chems eddine j'ai 23 ans , *étudiant* en master 1 A-R à **UCA** .
 
# ERP
# MES 
# scada
# PLC
# sensors & actuators

this is the automation tringle

![Screenshot of automation tringle.](https://www.erp-information.com/wp-content/uploads/2021/01/MES-2.png)


![Varible frequency drive internal architecteur](https://peacosupport.com/image/catalog/VFD/vfd-block-diagrams.jpg)
